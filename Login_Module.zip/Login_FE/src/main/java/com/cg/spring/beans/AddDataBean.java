package com.cg.spring.beans;

public class AddDataBean {
	private Integer merchant_id;
	private String merchant_name;
	private String merchant_email;
	private String merchant_location;

	public AddDataBean() {
		// TODO Auto-generated constructor stub
	}

	public AddDataBean(Integer merchant_id, String merchant_name, String merchant_email, String merchant_location) {
		super();
		this.merchant_id = merchant_id;
		this.merchant_name = merchant_name;
		this.merchant_email = merchant_email;
		this.merchant_location = merchant_location;
	}

	public Integer getMerchant_id() {
		return merchant_id;
	}

	public void setMerchant_id(Integer merchant_id) {
		this.merchant_id = merchant_id;
	}

	public String getMerchant_name() {
		return merchant_name;
	}

	public void setMerchant_name(String merchant_name) {
		this.merchant_name = merchant_name;
	}

	public String getMerchant_email() {
		return merchant_email;
	}

	public void setMerchant_email(String merchant_email) {
		this.merchant_email = merchant_email;
	}

	public String getMerchant_location() {
		return merchant_location;
	}

	public void setMerchant_location(String merchant_location) {
		this.merchant_location = merchant_location;
	}

}
