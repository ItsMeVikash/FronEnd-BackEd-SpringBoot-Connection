package com.cg.spring.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.beans.AddDataBean;
import com.cg.spring.beans.LoginBeans;

@RestController
public class FrontEndController {

	@RequestMapping("/log")
	public ModelAndView logOn(@RequestParam String username, @RequestParam String password) {

		RestTemplate rt4 = new RestTemplate();
		String log = rt4.getForObject("http://localhost:8083/login?username=" + username + "&password=" + password,
				String.class);
		if (log.equals("success")) {
			return new ModelAndView("success", "cust", username);
		} else {
			return new ModelAndView("failure", "cust", username);
		}

	}

	@RequestMapping(value = "/add")
	public AddDataBean addData(@RequestParam String merchant_name, @RequestParam String merchant_email, @RequestParam String merchant_location) {
		RestTemplate rt4 = new RestTemplate();
		AddDataBean str = rt4.getForObject("http://localhost:8083/add?merchant_name="+merchant_name+"&merchant_email="+merchant_email+"&merchant_location="+merchant_location, AddDataBean.class);
		System.out.println("Data are: " + str.toString());
		return str;

	}
}
