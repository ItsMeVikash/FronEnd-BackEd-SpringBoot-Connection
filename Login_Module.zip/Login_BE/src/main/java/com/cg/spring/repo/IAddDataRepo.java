package com.cg.spring.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.spring.beans.AddDataBean;

@Repository
public interface IAddDataRepo extends CrudRepository<AddDataBean, Integer> {

}
