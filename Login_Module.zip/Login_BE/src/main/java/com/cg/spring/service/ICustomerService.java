package com.cg.spring.service;

import com.cg.spring.beans.AddDataBean;

public interface ICustomerService {
	public boolean check(String username, String password);

	public void addData(AddDataBean addDataBean);

}
