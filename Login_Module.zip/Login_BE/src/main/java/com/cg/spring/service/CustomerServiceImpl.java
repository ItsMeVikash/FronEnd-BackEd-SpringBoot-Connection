package com.cg.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.AddDataBean;
import com.cg.spring.beans.LoginBeans;
import com.cg.spring.repo.IAddDataRepo;
import com.cg.spring.repo.ICustomerRepo;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private ICustomerRepo repo;
	@Autowired
	private IAddDataRepo addDataRepo;

	@Override
	public boolean check(String username, String password) {
		LoginBeans bean = repo.findById(username).get();
		if (bean.getPassword().equals(password)) {
			return true;
		} else
			return false;

	}

	@Override
	public void addData(AddDataBean addDataBean) {
		addDataRepo.save(addDataBean);
	}
}
