package com.cg.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.beans.AddDataBean;
import com.cg.spring.service.ICustomerService;

@RestController
public class plpController {

	@Autowired
	private ICustomerService service;

	@RequestMapping(value = "/login{username}{password}")
	public String login(@RequestParam String username, @RequestParam String password) {
		boolean b = service.check(username, password);
		if (b) {
			return "success";

		} else {
			return "failed";
		}
	}

	@RequestMapping(value = "/add")
	public String addData(@RequestParam String merchant_name, @RequestParam String merchant_email,
			@RequestParam String merchant_location) {
		AddDataBean addDataBean = new AddDataBean();
		addDataBean.setMerchant_email(merchant_email);
		addDataBean.setMerchant_location(merchant_location);
		addDataBean.setMerchant_name(merchant_name);
		service.addData(addDataBean);
		return "added";
	}

}
